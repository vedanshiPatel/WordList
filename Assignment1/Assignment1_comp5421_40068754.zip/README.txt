Assignment 1

Name: Vedanshi Patel
ID: 40068754
COURSE: COMP5421
DATE: May 28th 2018

Contains following files:

1) WordlistDriver.cpp
2) WordList.h
3) WordList.cpp
4) WordData.h
5) WordData.cpp
6) NumList.h
7) NumList.cpp
8) input.txt
9) output.txt
10) README.txt